package com.invoice.controller;

import com.invoice.view.fullproductsWindow;
import com.invoice.view.windowInterface1;
import com.invoice.view.productWindow;

public class ControllerData {
	public windowInterface1 frame;
	public fullproductsWindow invoiceDialogWindow;
	public productWindow lineDialogWindow;

	public ControllerData() {
	}
}