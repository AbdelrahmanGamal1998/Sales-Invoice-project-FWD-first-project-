package com.invoice.controller;

import com.invoice.model.Invoice;
import com.invoice.model.fullproductsdetails;
import com.invoice.model.product;
import com.invoice.model.productdetails;
import com.invoice.view.fullproductsWindow;
import com.invoice.view.windowInterface1;
import com.invoice.view.productWindow;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class fulldetailed_controller implements ActionListener, ListSelectionListener {

    private ControllerData2 data = new ControllerData2(new ControllerData());

	public fulldetailed_controller(windowInterface1 frame) {
        this.data.data.frame = frame;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String actionCommand = e.getActionCommand();
        System.out.println("Action  : " + actionCommand);
        detectingButton(actionCommand);
    }

	private void detectingButton(String actionCommand) {
		switch (actionCommand) {
            case "Load File":
                loadingFileFromPc();
                break;
            case "Save File":
                savingFileInPc();
                break;
            case "Create New Invoice":
                creatingInvoice();
                break;
            case "Delete Invoice":
                deletingInvoice();
                break;
            case "Create New Item":
                creatingProduct();
                break;
            case "Delete Item":
                deletingProduct();
                break;
            case "createInvoiceCancel":
                cancelButton();
                break;
            case "createInvoiceOK":
                okButton();
                break;
            case "createLineOK":
                okLineButton();
                break;
            case "createLineCancel":
                cancelLineButton();
                break;
        }
	}

    @Override
    public void valueChanged(ListSelectionEvent e) {
        int selectedIndex = data.data.frame.getInvoiceTable().getSelectedRow();
        setting_fields(selectedIndex);
    }

	private void setting_fields(int selectedIndex) {
		if (selectedIndex != -1) {
            System.out.println("You have selected row: " + selectedIndex);
            Invoice currentInvoice = data.data.frame.getInvoices().get(selectedIndex);
            data.data.frame.getInvoiceNumLabel().setText("" + currentInvoice.getNum());
            data.data.frame.getInvoiceDateLabel().setText(currentInvoice.getDate());
            data.data.frame.getCustomerNameLabel().setText(currentInvoice.getCustomer());
            data.data.frame.getInvoiceTotalLabel().setText("" + currentInvoice.getInvoiceTotal());
            productdetails productdetails = new productdetails(currentInvoice.getLines());
            data.data.frame.getLineTable().setModel(productdetails);
            productdetails.fireTableDataChanged();
        }
	}

    private void loadingFileFromPc() {
        JFileChooser fc = new JFileChooser();
        try {
            int result = fc.showOpenDialog(data.data.frame);
            if (result == JFileChooser.APPROVE_OPTION) {
                List<String> headerLines = readingHeaderFile(fc);
         
                ArrayList<Invoice> invoicesArray = new ArrayList<>();
                parsingHeaderFile(headerLines, invoicesArray);
                System.out.println("Check point");
                result = fc.showOpenDialog(data.data.frame);
                parsingLineFile(fc, result, invoicesArray);
                data.data.frame.setInvoices(invoicesArray);
                fullproductsdetails fullproductsdetails = new fullproductsdetails(invoicesArray);
                data.data.frame.setInvoicesTableModel(fullproductsdetails);
                data.data.frame.getInvoiceTable().setModel(fullproductsdetails);
                data.data.frame.getInvoicesTableModel().fireTableDataChanged();
            }
        } catch (IOException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(data.data.frame, "Cannot read file", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

	private void parsingLineFile(JFileChooser fc, int result, ArrayList<Invoice> invoicesArray) throws IOException {
		if (result == JFileChooser.APPROVE_OPTION) {
		    List<String> lineLines = readingLineFile(fc);
		    System.out.println("Lines have been read");
		    for (String lineLine : lineLines) {
		        try {
		            String lineParts[] = lineLine.split(",");
		            int invoiceNum = Integer.parseInt(lineParts[0]);
		            String itemName = lineParts[1];
		            double itemPrice = Double.parseDouble(lineParts[2]);
		            int count = Integer.parseInt(lineParts[3]);
		            Invoice inv = null;
		            for (Invoice invoice : invoicesArray) {
		                if (invoice.getNum() == invoiceNum) {
		                    inv = invoice;
		                    break;
		                }
		            }

		            product product = new product(itemName, itemPrice, count, inv);
		            inv.getLines().add(product);
		        } catch (Exception ex) {
		            ex.printStackTrace();
		            JOptionPane.showMessageDialog(data.data.frame, "Error in line format", "Error", JOptionPane.ERROR_MESSAGE);
		        }
		    }
		    System.out.println("Check point");
		}
	}

	private List<String> readingLineFile(JFileChooser fc) throws IOException {
		File lineFile = fc.getSelectedFile();
		Path linePath = Paths.get(lineFile.getAbsolutePath());
		List<String> lineLines = Files.readAllLines(linePath);
		return lineLines;
	}

	private void parsingHeaderFile(List<String> headerLines, ArrayList<Invoice> invoicesArray) {
		for (String headerLine : headerLines) {
		    try {
		        String[] headerParts = headerLine.split(",");
		        int invoiceNum = Integer.parseInt(headerParts[0]);
		        String invoiceDate = headerParts[1];
		        String customerName = headerParts[2];

		        Invoice invoice = new Invoice(invoiceNum, invoiceDate, customerName);
		        invoicesArray.add(invoice);
		    } catch (Exception ex) {
		        ex.printStackTrace();
		        JOptionPane.showMessageDialog(data.data.frame, "Error in line format", "Error", JOptionPane.ERROR_MESSAGE);
		    }
		}
	}

	private List<String> readingHeaderFile(JFileChooser fc) throws IOException {
		File headerFile = fc.getSelectedFile();
		Path headerPath = Paths.get(headerFile.getAbsolutePath());
		List<String> headerLines = Files.readAllLines(headerPath);
		System.out.println("Invoices have been read");
		return headerLines;
	}

	
	
	
	
    private void savingFileInPc() {
        ArrayList<Invoice> invoices = data.data.frame.getInvoices();
        String headers = "";
        String lines = "";
        for (Invoice invoice : invoices) {
            String invCSV = invoice.getAsCSV();
            headers += invCSV;
            headers += "\n";

            for (product product : invoice.getLines()) {
                String lineCSV = product.getAsCSV();
                lines += lineCSV;
                lines += "\n";
            }
        }
        System.out.println("Check point");
        try {
            JFileChooser fc = new JFileChooser();
            int result = fc.showSaveDialog(data.data.frame);
            writeInFile(headers, lines, fc, result);
        } catch (Exception ex) {

        }
    }

	private void writeInFile(String headers, String products, JFileChooser fc, int result) throws IOException {
		if (result == JFileChooser.APPROVE_OPTION) {
		    File headerFile = fc.getSelectedFile();
		    FileWriter headerFileWrite = new FileWriter(headerFile);
		    headerFileWrite.write(headers);
		    headerFileWrite.flush();
		    headerFileWrite.close();
		    result = fc.showSaveDialog(data.data.frame);
		    if (result == JFileChooser.APPROVE_OPTION) {
		        File lineFile = fc.getSelectedFile();
		        FileWriter lineFileWrite = new FileWriter(lineFile);
		        lineFileWrite.write(products);
		        lineFileWrite.flush();
		        lineFileWrite.close();
		    }
		}
	}

    private void creatingInvoice() {
        data.data.invoiceDialogWindow = new fullproductsWindow(data.data.frame);
        data.data.invoiceDialogWindow.setVisible(true);
    }

    private void deletingInvoice() {
        int selectedRow = data.data.frame.getInvoiceTable().getSelectedRow();
        if (selectedRow != -1) {
            data.data.frame.getInvoices().remove(selectedRow);
            data.data.frame.getInvoicesTableModel().fireTableDataChanged();
        }
    }

    private void creatingProduct() {
        data.data.lineDialogWindow = new productWindow(data.data.frame);
        data.data.lineDialogWindow.setVisible(true);
    }

    private void deletingProduct() {
        int selectedRow = data.data.frame.getLineTable().getSelectedRow();

        deleteproduct(selectedRow);
    }

	private void deleteproduct(int selectedRow) {
		if (selectedRow != -1) {
            productdetails productdetails = (productdetails) data.data.frame.getLineTable().getModel();
            productdetails.getLines().remove(selectedRow);
            productdetails.fireTableDataChanged();
            data.data.frame.getInvoicesTableModel().fireTableDataChanged();
        }
	}

    private void cancelButton() {
        data.data.invoiceDialogWindow.setVisible(false);
        data.data.invoiceDialogWindow.dispose();
        data.data.invoiceDialogWindow = null;
    }

    private void okButton() {
        String date = data.data.invoiceDialogWindow.getInvDateField().getText();
        String person = data.data.invoiceDialogWindow.getCustNameField().getText();
        int num = data.data.frame.getNextInvoiceNum();
        try {
            String[] dateParts = date.split("-");  
            parsingDateFormat(date, person, num, dateParts);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(data.data.frame, "Wrong  format", "Error", JOptionPane.ERROR_MESSAGE);
        }

    }

	private void parsingDateFormat(String date, String customer, int num, String[] dateParts) {
		if (dateParts.length < 3) {
		    JOptionPane.showMessageDialog(data.data.frame, "Wrong  format", "Error", JOptionPane.ERROR_MESSAGE);
		} else {
		    int day = Integer.parseInt(dateParts[0]);
		    int month = Integer.parseInt(dateParts[1]);
		    int year = Integer.parseInt(dateParts[2]);
		    if (day > 31 || month > 12) {
		        JOptionPane.showMessageDialog(data.data.frame, "Wrong format", "Error", JOptionPane.ERROR_MESSAGE);
		    } else {
		        Invoice invoice = new Invoice(num, date, customer);
		        data.data.frame.getInvoices().add(invoice);
		        data.data.frame.getInvoicesTableModel().fireTableDataChanged();
		        data.data.invoiceDialogWindow.setVisible(false);
		        data.data.invoiceDialogWindow.dispose();
		        data.data.invoiceDialogWindow = null;
		    }
		}
	}

    private void okLineButton() {
        String item = data.data.lineDialogWindow.getItemNameField().getText();
        String countStr = data.data.lineDialogWindow.getItemCountField().getText();
        String priceStr = data.data.lineDialogWindow.getItemPriceField().getText();
        int count = Integer.parseInt(countStr);
        double price = Double.parseDouble(priceStr);
        int selectedInvoice = data.data.frame.getInvoiceTable().getSelectedRow();
        selectedinvoice(item, count, price, selectedInvoice);
        data.data.lineDialogWindow.setVisible(false);
        data.data.lineDialogWindow.dispose();
        data.data.lineDialogWindow = null;
    }

	private void selectedinvoice(String item, int count, double price, int selectedInvoice) {
		if (selectedInvoice != -1) {
            Invoice invoice = data.data.frame.getInvoices().get(selectedInvoice);
            product product = new product(item, price, count, invoice);
            invoice.getLines().add(product);
            productdetails productdetails = (productdetails) data.data.frame.getLineTable().getModel();
            //linesTableModel.getLines().add(line);
            productdetails.fireTableDataChanged();
            data.data.frame.getInvoicesTableModel().fireTableDataChanged();
        }
	}

    private void cancelLineButton() {
        data.data.lineDialogWindow.setVisible(false);
        data.data.lineDialogWindow.dispose();
        data.data.lineDialogWindow = null;
    }

}
