package com.invoice.controller;

public class ControllerData2 {
	public ControllerData data;

	public ControllerData2(ControllerData data) {
		this.data = data;
	}
}