
package com.invoice.model;

import com.invoice.model.Invoice;

public class product {
    private productdata data = new productdata();

	public product() {
    }

    public product(String item, double price, int count, Invoice invoice) {
        this.data.product = item;
        this.data.productPrice = price;
        this.data.productCounting = count;
        this.data.productsInvoice = invoice;
    }

    public double getLineTotal() {
        return data.productPrice * data.productCounting;
    }
    
    public int getCount() {
        return data.productCounting;
    }

    public void setCount(int count) {
        this.data.productCounting = count;
    }

    public String getItem() {
        return data.product;
    }

    public void setItem(String item) {
        this.data.product = item;
    }

    public double getPrice() {
        return data.productPrice;
    }

    public void setPrice(double price) {
        this.data.productPrice = price;
    }

    @Override
    public String toString() {
        return "Line{" + "numberr=" + data.productsInvoice.getNum() + ", product=" + data.product + ", product price=" + data.productPrice + ", product counting=" + data.productCounting + '}';
    }

    public Invoice getInvoice() {
        return data.productsInvoice;
    }
    
    public String getAsCSV() {
        return data.productsInvoice.getNum() + "," + data.product + "," + data.productPrice + "," + data.productCounting;
    }
    
}
