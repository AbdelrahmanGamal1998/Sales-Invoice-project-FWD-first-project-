package com.invoice.model;

import com.invoice.model.Invoice;

public class productdata {
	public String product;
	public double productPrice;
	public int productCounting;
	public Invoice productsInvoice;

	public productdata() {
	}
}