
package com.invoice.model;

import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;

import com.invoice.model.Invoice;

public class fullproductsdetails extends AbstractTableModel {
    private ArrayList<Invoice> peopleInvoices;
    private String[] invoicecol = {"No.", "Date", "person", "Total"};
    
    public fullproductsdetails(ArrayList<Invoice> invoices) {
        this.peopleInvoices = invoices;
    }
    
    @Override
    public int getRowCount() {
        return peopleInvoices.size();
    }

    @Override
    public int getColumnCount() {
        return invoicecol.length;
    }

    @Override
    public String getColumnName(int column) {
        return invoicecol[column];
    }
    
    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Invoice invoice = peopleInvoices.get(rowIndex);
        
        switch (columnIndex) {
            case 0: return invoice.getNum();
            case 1: return invoice.getDate();
            case 2: return invoice.getCustomer();
            case 3: return invoice.getInvoiceTotal();
            default : return "";
        }
    }
}
