
package com.invoice.model;

import java.util.ArrayList;

import com.invoice.model.product;

public class Invoice {
    private int invoiceNumber;
    private String invoiceDate;
    private String person;
    private ArrayList<product> products;
    
    public Invoice() {
    }

    public Invoice(int num, String date, String customer) {
        this.invoiceNumber = num;
        this.invoiceDate = date;
        this.person = customer;
    }

    public double getInvoiceTotal() {
        double total = invoice_null();
        return total;
    }


    
    public ArrayList<product> getLines() {
        if (products == null) {
            products = new ArrayList<>();
        }
        return products;
    }

    public String getCustomer() {
        return person;
    }

    public void setCustomer(String customer) {
        this.person = customer;
    }
	private double invoice_null() {
		double total = 0.0;
        for (product product : getLines()) {
            total += product.getLineTotal();
        }
		return total;
	}
    public int getNum() {
        return invoiceNumber;
    }

    public void setNum(int num) {
        this.invoiceNumber = num;
    }

    public String getDate() {
        return invoiceDate;
    }

    public void setDate(String date) {
        this.invoiceDate = date;
    }

    @Override
    public String toString() {
        return "Invoice{" + "number=" + invoiceNumber + ", invoice date=" + invoiceDate + ",person=" + person + '}';
    }
    
    public String getAsCSV() {
        return invoiceNumber + "," + invoiceDate + "," + person;
    }
    
}
