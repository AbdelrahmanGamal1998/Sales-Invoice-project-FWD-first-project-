
package com.invoice.model;

import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;

import com.invoice.model.product;

public class productdetails extends AbstractTableModel {

    private ArrayList<product> products;
    private String[] columns = {"No.", "product Name", "product Price", "product counting", "products  Total"};

    public productdetails(ArrayList<product> products) {
        this.products = products;
    }

    public ArrayList<product> getLines() {
        return products;
    }
    
    
    @Override
    public int getRowCount() {
        return products.size();
    }

    @Override
    public int getColumnCount() {
        return columns.length;
    }

    @Override
    public String getColumnName(int x) {
        return columns[x];
    }
    
    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        product product = products.get(rowIndex);
        
        return detectValue(columnIndex, product);
    }

	private Object detectValue(int columnIndex, product product) {
		switch(columnIndex) {
            case 0: return product.getInvoice().getNum();
            case 1: return product.getItem();
            case 2: return product.getPrice();
            case 3: return product.getCount();
            case 4: return product.getLineTotal();
            default : return "";
        }
	}
    
}
