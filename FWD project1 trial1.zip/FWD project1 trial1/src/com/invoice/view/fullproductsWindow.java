
package com.invoice.view;

import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JTextField;

import com.invoice.view.windowInterface1;

public class fullproductsWindow extends JDialog {
    private JTextField personnameFieldd;
    private JTextField invDateField;
    private JLabel personLabel;
    private JLabel invoicedatelabel;
    private JButton okayButtonPressed;
    private JButton cancelButtonPressed;

    public fullproductsWindow(windowInterface1 frame) {
        personLabel = new JLabel("Customer Name:");
        personnameFieldd = new JTextField(20);
        invoicedatelabel = new JLabel("Invoice Date:");
        invDateField = new JTextField(25);
        okayButtonPressed = new JButton("OK");
        cancelButtonPressed = new JButton("Cancel");
        
        okayButtonPressed(frame);
        
        pack();
        
    }

	private void okayButtonPressed(windowInterface1 frame) {
		okayButtonPressed.setActionCommand("createInvoiceOK");
        cancelButtonPressed.setActionCommand("createInvoiceCancel");
        
        okayButtonPressed.addActionListener(frame.getController());
        cancelButtonPressed.addActionListener(frame.getController());
        setLayout(new GridLayout(3, 2));
        
        add(invoicedatelabel);
        add(invDateField);
        add(personLabel);
        add(personnameFieldd);
        add(okayButtonPressed);
        add(cancelButtonPressed);
	}

    public JTextField getCustNameField() {
        return personnameFieldd;
    }

    public JTextField getInvDateField() {
        return invDateField;
    }
    
}
