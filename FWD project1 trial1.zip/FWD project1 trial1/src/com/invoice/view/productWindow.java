
package com.invoice.view;

import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JTextField;

import com.invoice.view.windowInterface1;


public class productWindow extends JDialog{
    private JTextField productName;
    private JTextField productCount;
    private JTextField productPrice;
    private JLabel productNameField;
    private JLabel productCountFiled;
    private JLabel productPriceFiled;
    private JButton okayButton;
    private JButton cancelButton;
    
    public productWindow(windowInterface1 frame) {
        productName = new JTextField(20);
        productNameField = new JLabel("productName");
        
        productCount = new JTextField(20);
        productCountFiled = new JLabel("product Counting");
        
        productPrice = new JTextField(20);
        productPriceFiled = new JLabel("product Price");
        
        okayButton = new JButton("OK Button");
        cancelButton = new JButton("Cancel Button ");
        
        okayButton.setActionCommand("createLineOK");
        cancelButton.setActionCommand("createLineCancel");
        
        okayButton.addActionListener(frame.getController());
        cancelButton.addActionListener(frame.getController());
        setLayout(new GridLayout(4, 2));
        
        add(productNameField);
        add(productName);
        add(productCountFiled);
        add(productCount);
        add(productPriceFiled);
        add(productPrice);
        add(okayButton);
        add(cancelButton);
        
        pack();
    }

    public JTextField getItemNameField() {
        return productName;
    }

    public JTextField getItemCountField() {
        return productCount;
    }

    public JTextField getItemPriceField() {
        return productPrice;
    }
}
